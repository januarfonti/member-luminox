</div>

<div class="row">
	<div class="col-xs-12">
		<div class="alert alert-info alert-block fade in">
		  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		  Selamat datang pada halaman admin.
		</div>
	</div>
</div>


<div class="row">
 <div class="col-xs-6 well">
  Posting Terakhir
</div>

 <div class="col-xs-6 well">
  Posting Terakhir 
</div>