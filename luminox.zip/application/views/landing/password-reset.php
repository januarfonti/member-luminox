<!DOCTYPE html>
<html>
  <head>
    <title>LUMINOX</title>
	<link rel="shortcut icon" href="<?php echo base_url('assets/favicon.png');?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet" media="screen">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="../../assets/js/html5shiv.js"></script>
      <script src="../../assets/js/respond.min.js"></script>
    <![endif]-->
	<style>
  .center {text-align: center; margin-left: auto; margin-right: auto; margin-bottom: auto; margin-top: 200px;}
</style>
  </head>
  <body>
    
    <div class="hero-unit center">
    <h1>Password telah berhasil direset </h1>
    <br />
    <p>Password anda telah berhasil direset</p>
    
    
  </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    
	<script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
  </body>
</html>



<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $page_title; ?></title>
</head>

<body class="<?php echo $body_class; ?>">
<h1><?php echo $page_title; ?></h1>
You have successfully reset your password.
</body>
</html>