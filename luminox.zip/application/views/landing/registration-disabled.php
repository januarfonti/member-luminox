<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $page_title; ?></title>
</head>

<body class="<?php echo $body_class; ?>">
<h1><?php echo $page_title; ?></h1>
Registration is disabled.
</body>
</html>