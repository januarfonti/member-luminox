<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $page_title; ?></title>
</head>

<body class="<?php echo $body_class; ?>">
<h1><?php echo $page_title; ?></h1>
A confirmation email has been sent to <strong><?php echo $email; ?></strong>. Follow the instructions in the email to complete this change of email address.
</body>
</html>