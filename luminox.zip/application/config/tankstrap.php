<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config["tankstrap"] = array (
	
	"bootstrap_path"          => "../asset/css/bootstrap.css",
	//"bootstrap_path"          => "http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.1/css/bootstrap-combined.min.css",
	"login_page_title"        => "Login to YOUR APPLICATION",
	"delete_page_title"       => "Delete Account",
	"send_again_page_title"   => "Send Again",
	"register_page_title"     => "Register Account",
	"general_page_title"      => "Notice",
	"forgot_page_title"       => "Forgot Password",
	"change_pw_page_title"    => "Change Password",
	"change_email_page_title" => "Change Email Address",
);
